<?php
//Ip de la pc servidor de base de datos
define("DB_HOST","localhost");

/*
//datos de acceso local
define("DB_HOST","localhost");
define("DB_NAME", "massiva");
define("DB_USERNAME", "root");
define("DB_PASSWORD", "");
define("DB_ENCODE","utf8");
*/

///datos para servidor
define("DB_HOST","localhost");
define("DB_NAME", "sinad18_massiva");
define("DB_USERNAME", "sinad18_massiva");
define("DB_PASSWORD", "B}[&iCPR8#B[");
define("DB_ENCODE","utf8");
?>