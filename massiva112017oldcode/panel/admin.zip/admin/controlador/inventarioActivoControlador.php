<?php
@session_start();	
	date_default_timezone_set("America/Mexico_City");
    //session_start();
	//error_reporting(E_ALL);
	//ini_set('display_errors','1');

   
    /****************************************************************/
    // FUNCIONES GENERALES PARA EL SITIO                            //
    // CREACION DEL ARCHIVO: 27/08/2018                             //
    // MODIFICA Y/O TRABAJA: Azael HV                               //
    // PROYECTO: http://www.elinnovador.mx/                         //
    /****************************************************************/

    //instanciamos el modelo 
    require_once "../modelo/inventarioActivoModelo.php";
    $invactivo = new invactivo();

	//*********************Variables generales***************************************//
    $fechaAccion = date("Y-m-d H:i:s");
	$usuarioSe = $_SESSION['id_usuario'];
    $accion = $_POST['accion'];
	
	/* Valores para agregar servicios */
	$satcodigo = ($_POST['satcodigo'] == '')? '' : $_POST['satcodigo'];
	$titulo = ($_POST['titulo'] == '')? '' : $_POST['titulo'];
	
	/* Valor para eliminar el servicio */
	$idServicio = ($_POST['idServicio'] == '')? '' : $_POST['idServicio'];
	
	//**********************valores producto nuevo****************************//
	$satdes = ($_POST['satdes'] == '')? '' : $_POST['satdes'];
	$unidadsat = ($_POST['unidadsat'] == '')? '' : $_POST['unidadsat'];
	$tipo = ($_POST['tipo'] == '')? '' : $_POST['tipo'];
	$cantidad = ($_POST['cantidad'] == '')? '' : $_POST['cantidad'];
	$precioCompra = ($_POST['precioCompra'] == '')? '' : $_POST['precioCompra'];
	$precioVenta = ($_POST['precioVenta'] == '')? '' : $_POST['precioVenta'];
	$descuento = ($_POST['descuento'] == '')? '' : $_POST['descuento'];
	$proveedor = ($_POST['proveedor'] == '')? '' : $_POST['proveedor'];
	$comentarios = ($_POST['comentarios'] == '')? '' : $_POST['comentarios'];


	//**********************valores para agregar entradas a productos nuevos****************************//
	$idInventarioE = ($_POST['idInventarioE'] == '')? '' : $_POST['idInventarioE'];
	$CasntE = ($_POST['CasntE'] == '')? '' : $_POST['CasntE'];///este no se envia
	$fechaEntradaE = ($_POST['fechaEntradaE'] == '')? '' : $_POST['fechaEntradaE'];
	$cantidadE = ($_POST['cantidadE'] == '')? '' : $_POST['cantidadE'];
	$precioE = ($_POST['precioE'] == '')? '' : $_POST['precioE'];
	$proveedorE = ($_POST['proveedorE'] == '')? '' : $_POST['proveedorE'];
	$unidadE = ($_POST['unidadE'] == '')? '' : $_POST['unidadE'];

	//**********************valores para agregar Salidas a productos nuevos****************************//
	$idInventarioE1 = ($_POST['idInventarioE1'] == '')? '' : $_POST['idInventarioE1'];
	$CasntE1 = ($_POST['CasntE1'] == '')? '' : $_POST['CasntE1'];///este no se envia
	$fechaEntradaE1 = ($_POST['fechaEntradaE1'] == '')? '' : $_POST['fechaEntradaE1'];
	$cantidadE1 = ($_POST['cantidadE1'] == '')? '' : $_POST['cantidadE1'];
	$precioE1 = ($_POST['precioE1'] == '')? '' : $_POST['precioE1'];
	$proveedorE1 = ($_POST['proveedorE1'] == '')? '' : $_POST['proveedorE1'];
	$unidadE1 = ($_POST['unidadE1'] == '')? '' : $_POST['unidadE1'];
	
	//**********************hacemos consulta para editar el producto****************************//
	$idConProd = $_POST['idConProd'];
    if($idConProd != ""){
        $data=$invactivo->consultaEdita($idConProd);
		echo json_encode($data);
	}
	

	
	/****************************Acciones dependiendo de la variable*************************************///
    switch ($accion) {
		/* agregamos un nuevo servicio */
		case "nuevoServicio":
			$rspta = $invactivo->nuevoServicio($satcodigo,$titulo,$usuarioSe,$fechaAccion);
			if($rspta){
				///guardamo el evento en el log
				$rsptaLog = $invactivo->accionNuevoSerivio($usuarioSe,$fechaAccion);
				if($rsptaLog){  header('location:../index.php?secc=inventario&serpro=1');}
			
			}else{	header('location:../index.php?secc=inventario&serpro=2');}
		break;

		/* Eliminamos el servicio */
		case "eliminaServicio":
			$rspta = $invactivo->eliminoServicio($idServicio);
			if($rspta){
				///guardamo el evento en el log
				$rsptaLog = $invactivo->accionEliminoiSer($usuarioSe,$fechaAccion);
				if($rsptaLog){  header('location:../index.php?secc=inventario&serpro=2');}
			
			}else{	header('location:../index.php?secc=inventario&serpro=9');}
        break;


		case "nuevoProducto":
			/* subimos archivo */
			$nombre_archivo = "activo_".$usuarioSe."_".$_FILES['foto']['name'];
			$nombreFinal = $nombre_archivo;
			$uploaddir = '../contenedor/inventarioActivos/';
			$directorio = $uploaddir. basename($nombreFinal);
			move_uploaded_file($_FILES["foto"]["tmp_name"], $directorio);

			$rspta = $invactivo->nuevoProdcuto($usuarioSe,$satdes,$unidadsat,$tipo,$cantidad,$precioCompra,$precioVenta,$descuento,$proveedor,$nombreFinal,$comentarios,$fechaAccion);
			if($rspta){
				///guardamo el evento en el log
				$rsptaLog = $invactivo->accionAgregaProd($usuarioSe,$fechaAccion);
				if($rsptaLog){  header('location:../index.php?secc=inventario&serpro=3');}
			}else{	header('location:../index.php?secc=inventario&serpro=9');}
		break;
		
		/* entradas de prodcutos */
		case "agregamosEntradaProducto":
			$rspta = $invactivo->agreEntrda($idInventarioE,$fechaEntradaE,$cantidadE,$precioE,$proveedorE,$unidadE,$usuarioSe,$fechaAccion);
			if($rspta){
				//actualizamos el monto del prodcuto en inicial
				$actMonto = $CasntE + $cantidadE;
				$actmon = $invactivo->actMontoOri($actMonto,$idInventarioE);
				if($actmon){
					///guardamo el evento en el log
					$rsptaLog = $invactivo->accionLogAgregCan($usuarioSe,$fechaAccion);
					  header('location:../index.php?secc=inventario&serpro=4');
				}
			}else{	header('location:../index.php?secc=inventario&serpro=9');}
		break;

		/* Agregamos salida al producto */
		case "agreSalida":
			
			$rspta = $invactivo->agreSald($idInventarioE1,$fechaEntradaE1,$cantidadE1,$precioE1,$proveedorE1,$unidadE1,$usuarioSe,$fechaAccion);
			if($rspta){
				//actualizamos el monto del prodcuto en inicial
				$actMonto1 = $CasntE1 - $cantidadE1;
				$actmon = $invactivo->actMontoOri2($actMonto1,$idInventarioE1);
				if($actmon){
					///guardamo el evento en el log
					$rsptaLog = $invactivo->accionAgregaSalida($usuarioSe,$fechaAccion);
					  header('location:../index.php?secc=inventario&serpro=5');
				}
			}else{	header('location:../index.php?secc=inventario&serpro=9');}
	
		break;



		//editra producto
		case "editarProducto":
			///primero borramos la imagen
			if ($tamano > 0 ){ ////caso cuando el usuario cambie la imagen
			
				$archivoBorro = "../contenedor/inventarioActivos/".$imagen1;
				unlink($archivoBorro);

				$nombre_archivo = $_FILES['imagensube']["name"];
				$nombreFinal = $nombre_archivo;
				$uploaddir = '../contenedor/inventarioActivos/';
				$directorio = $uploaddir. basename($nombreFinal);
				move_uploaded_file($_FILES["imagensube"]["tmp_name"], $directorio);
				//guardamos el valor en la base de datos
				
				$editarElem = $invactivo->editarProdu($idInventario,$nombre1,$descripcion1,$cantidad1,$unidad1,$ubicacion1,$codigo1,$precioFinal1,$descuentos1,$proveedor1,$precio1,$nombreFinal);
            	if($editarElem){ 
					$rsptaLog = $invactivo->accionLogEdita($usuarioSe,$fechaAccion);
					if($rsptaLog){$resultado = "<div class='alert alert-success text-center'>Se edito su producto.</div>";}
				}else{
					$resultado = "<div class='alert alert-danger text-center'>Ocurrio un error favor de verificar sus datos .</div>";
				}
			}else{
				
				$editarElem = $invactivo->editarProdu2($idInventario,$nombre1,$descripcion1,$cantidad1,$unidad1,$ubicacion1,$codigo1,$precioFinal1,$descuentos1,$proveedor1,$precio1,$imagen1);
            	if($editarElem){ 
				$rsptaLog = $invactivo->accionLogEdita($usuarioSe,$fechaAccion);
				if($rsptaLog){ 	$resultado = "<div class='alert alert-success text-center'>Se edito su noticia web.</div>";	}
				else{ $resultado = "<div class='alert alert-danger text-center'>Ocurrio un error favor de verificar sus datos .</div>";	}
			}

		}
            
		break;
			
        
		 
			
       
    }
 
?>
<html>
	<?php include '../estructura/header_acciones.php';?>	
	<body style="background-color: #FFFFFF !important;">
		<?php echo $resultado;?>
	</body>
</html>