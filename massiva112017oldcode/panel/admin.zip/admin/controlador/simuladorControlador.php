<?php
@session_start();	
//instanaciamos la funcion de php mailer
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\Exception;

	require '../plugins/phpmailer/Exception.php';
	require '../plugins/phpmailer/PHPMailer.php';
	require '../plugins/phpmailer/SMTP.php';
	
    //session_start();
	//error_reporting(E_ALL);
	//ini_set('display_errors','1');

   
    /****************************************************************/
    // FUNCIONES GENERALES PARA EL SITIO                            //
    // CREACION DEL ARCHIVO: 27/08/2018                             //
    // MODIFICA Y/O TRABAJA: Azael HV                               //
    // PROYECTO: http://www.elinnovador.mx/                         //
    /****************************************************************/

    //instanciamos el modelo 
    require_once "../modelo/simuladorModelo.php";
    $simula = new simula();

	//*********************Variables generales***************************************//
    $fechaAccion = date("Y-m-d H:i:s");
	$usuarioSe = $_SESSION['id_usuario'];
    $accion = $_POST['accion'];
    $accion2 = $_POST['accion2'];
    
	//**********************valores para agregar nuevo seguro****************************//
	
	$montoCal = ($_POST['montoCal'] == '')? '' : $_POST['montoCal'];
	$rfcR = ($_POST['rfc'] == '')? '' : $_POST['rfc'];
	$rfc = strtoupper($rfcR);
	$nombre = ($_POST['nombre'] == '')? '' : $_POST['nombre'];
	$ape_paterno = ($_POST['ape_paterno'] == '')? '' : $_POST['ape_paterno'];
	$ape_materno = ($_POST['ape_materno'] == '')? '' : $_POST['ape_materno'];
	$correo = ($_POST['correo'] == '')? '' : $_POST['correo'];
	$periodoRegu = ($_POST['periodoRegu'] == '')? '' : $_POST['periodoRegu'];
	$obliga = ($_POST['obliga'] == '')? '' : $_POST['obliga'];
	$cheInteres = ($_POST['cheInteres'] == '')? '' : $_POST['cheInteres'];
	$cheasalariado = ($_POST['cheasalariado'] == '')? '' : $_POST['cheasalariado'];
	$chearrendamiento = ($_POST['chearrendamiento'] == '')? '' : $_POST['chearrendamiento'];
	$cheservicios = ($_POST['cheservicios'] == '')? '' : $_POST['cheservicios'];
	$cheempresaria = ($_POST['cheempresaria'] == '')? '' : $_POST['rfc'];
	$cherif = ($_POST['cherif'] == '')? '' : $_POST['cherif'];
	$estatus = 1;
	$creado = 1;

	$montoCadena = "$".$montoCal." ";

	//valores para personas morales
	$montoCal1 = ($_POST['montoCal1'] == '')? '' : $_POST['montoCal1'];
	$rfcR = ($_POST['rfc1'] == '')? '' : $_POST['rfc1'];
	$rfc1 = strtoupper($rfcR);
	$nombre1 = ($_POST['nombre1'] == '')? '' : $_POST['nombre1'];
	$ape_paterno1 = ($_POST['ape_paterno1'] == '')? '' : $_POST['ape_paterno1'];
	$ape_materno1 = ($_POST['ape_materno1'] == '')? '' : $_POST['ape_materno1'];
	$correo1 = ($_POST['correo1'] == '')? '' : $_POST['correo1'];

	$periodoRegu2 = ($_POST['periodoRegu2'] == '')? '' : $_POST['periodoRegu2'];
	$obliga2 = ($_POST['obliga2'] == '')? '' : $_POST['obliga2'];
	$movIngUno2 = ($_POST['movIngUno2'] == '')? '' : $_POST['movIngUno2'];
	$regeneral = ($_POST['regeneral'] == '')? '' : $_POST['regeneral'];
	$fineslucra = ($_POST['fineslucra'] == '')? '' : $_POST['fineslucra'];
	
	if($accion2 == 'pre'){
	$estatus = 2;
	$creado = 2;
	$estatus1 = 2;
	$creado1 = 2;}
	else{
		$estatus = 1;
		$creado = 1;
		$estatus1 = 1;
		$creado1 = 1;
		$mesesin = 0;
	}

	$montoCadena1 = "$".$montoCal1." ";

	//valores para el reeenvio de la infomacion
	$montoEnvia = ($_POST['montoEnvia'] == '')? '' : $_POST['montoEnvia'];
	$correEnvia = ($_POST['correEnvia'] == '')? '' : $_POST['correEnvia'];

	//valores para eliminar
	$idContaAtrasada = ($_POST['idContaAtrasada'] == '')? '' : $_POST['idContaAtrasada'];
	
	//**********************valores formulario edicion****************************//

 	switch ($accion) {
 		//agregamos el nuevo seguro
		case "agergarAte":
			
			
				$rspta = $simula->agregacontaatrapf2($montoCal,$rfc,$nombre,$ape_paterno,$ape_materno,$correo,$periodoRegu,$obliga,$cheInteres,$cheasalariado,$chearrendamiento,$cheservicios,$cheempresaria,$cherif,$estatus,$creado,$fechaAccion,$usuarioSe,$mesesin);	
			
			
			if($rspta){
				///guardamo el evento en el log
				$rsptaLog = $simula->accionAgregoContapf($usuarioSe,$fechaAccion);
				if($rsptaLog){ 

					$hola = strip_tags($correo);
					//envaismos el correo al cliente
					$mail = new PHPMailer(true);                              
			        try {
			                //Server settings
			                $mail->SMTPDebug = 0;
			                $mail->isSMTP();
			                $mail->Host = 'mail.massiva.mx'; 
			                $mail->SMTPAuth = true;
			                $mail->Username = 'atencionclientes@massiva.mx';
			                $mail->Password = 'AtenCli_19';
			                $mail->SMTPSecure = 'tls';
			                $mail->Port = 587;

			                //Recipients
			                $mail->setFrom('atencionclientes@massiva.mx', 'Atención a clientes');
			                $mail->addAddress($hola, 'Cliente');     // Add a recipient
			                $mail->addAddress('dsanchez@massiva.mx','');               // Name is optional
			                $mail->addAddress('ahernandez@massiva.mx');               // Name is optional

			                //Content
			                $mail->CharSet = 'UTF-8';
			                $mail->isHTML(true);                                  // Set email format to HTML
			                $mail->Subject = 'Cotización de contabilidad atrasada massiva';
			                $mail->Body    = "
			                         <!DOCTYPE html>
										<html lang='es'>
										<head>
										<meta http-equiv='Content-Type' content='text/html; charset=utf-8'/> 
										</head>
										<body>
											<div style='text-align:center;'>
											<table style='width: 100%' style='margin: 0 auto;'>
												<tr>
													<td colspan='2' style='align-content: center' face='arial'><font face='arial'><h1 style='align-items: center;' face='arial'>Cotización Contabilidad Atrasada<br></h1></font></td>
												</tr>

												<tr valign='middle'>
													<td colspan='2' style='align-content: center' face='arial' valign='middle'>
														<font face='arial'><h4 style='align-items: center;' face='arial'>
														<h5>
															<b>Forma jurídica:</b> Persona Física<br>
															<b>Costo: </b>  {$montoCadena} pesos.<br><br>

															<b>Ya recibimos tu registro con tu e-firma para el análisis de tu contabilidad con exactitud. 
															<br> Esta cotización podría variar después del análisis por massiva. </b> 
															
														</h5>
														</font>
													</td>
												</tr>

												<tr><td><br></td></tr>

												<tr>
													<td colspan='2'>
														<font color='gray' face='arial'>El tiempo de análisis es de 1 a 2 días hábiles. Si hay algún cambio, te lo haremos saber 
														a través de un mail, sino existen cambios en tu cotización procederemos a la realización
														de tu contabilidad atrasada, este tiempo será de 5 a 7 días hábiles.

													</td>
												</tr>

												<tr><td></td></tr>
												<tr>
													<td colspan='2' style='align-content: center' face='arial' valign='middle'><font face='arial' color='gray'><small face='arial'>Atentamente.<br>El equipo de massiva</small></font></td>
												</tr>
											</table>
											</div>
										</body>
										</html>";
			                //enviamos el correo
			                $mail->send();
			                //redireccionamos a la pagina para enviar mensaje
			                
			        } catch (Exception $e) {
			             $hola = '1';
			        }
					header ('location:../index.php?secc=simuladores&guaSim=1');
				}	
			}else{
				header ('location:../index.php?secc=simuladores&guaSim=2');
			}
	
		break;
			
		case "agergarAte1":
			
			$rspta = $simula->agregacontaatrapm($montoCal1,$rfc1,$nombre1,$ape_paterno1,$ape_materno1,$correo1,$periodoRegu2,$obliga2,$movIngUno2,$regeneral,$fineslucra,$estatus1,$creado1,$fechaAccion,$usuarioSe);
			 if($rspta){
				///guardamo el evento en el log
				$rsptaLog = $simula->accionAgregoContapm($usuarioSe,$fechaAccion);
				if($rsptaLog){ 

					$hola = strip_tags($correo1);
					//envaismos el correo al cliente
					$mail = new PHPMailer(true);                              
			        try {
			                //Server settings
			                $mail->SMTPDebug = 0;
			                $mail->isSMTP();
			                $mail->Host = 'mail.massiva.mx'; 
			                $mail->SMTPAuth = true;
			                $mail->Username = 'atencionclientes@massiva.mx';
			                $mail->Password = 'AtenCli_19';
			                $mail->SMTPSecure = 'tls';
			                $mail->Port = 587;

			                //Recipients
			                $mail->setFrom('atencionclientes@massiva.mx', 'Atención a clientes');
			                $mail->addAddress($hola, 'Cliente');     // Add a recipient
			                $mail->addAddress('dsanchez@massiva.mx','Recuperación de claves');               // Name is optional
			                $mail->addAddress('ahernandez@massiva.mx','Recuperación de claves');               // Name is optional

			                //Content
			                $mail->CharSet = 'UTF-8';
			                $mail->isHTML(true);                                  // Set email format to HTML
			                $mail->Subject = 'Cotización de contabilidad atrasada massiva';
			                $mail->Body    = "
			                         <!DOCTYPE html>
										<html lang='es'>
										<head>
										<meta http-equiv='Content-Type' content='text/html; charset=utf-8'/> 
										</head>
										<body>
											<div style='text-align:center;'>
											<table style='width: 100%' style='margin: 0 auto;'>
												<tr>
													<td colspan='2' style='align-content: center' face='arial'><font face='arial'><h1 style='align-items: center;' face='arial'>Cotización Contabilidad Atrasada<br></h1></font></td>
												</tr>

												<tr valign='middle'>
													<td colspan='2' style='align-content: center' face='arial' valign='middle'>
														<font face='arial'><h4 style='align-items: center;' face='arial'>
														<h5>
															<b>Forma jurídica:</b> Persona Moral.<br>
															<b>Costo: </b>  {$montoCadena1} .<br><br>

															<b>Una vez obtengamos tu e-firma podremos analizar tu contabilidad con exactitud.
															<br> Esta cotización podría variar después del análisis por massiva.</b> 
															
														</h5>
														</font>
													</td>
												</tr>

												<tr><td><br></td></tr>

												<tr>
													<td colspan='2'>
														<font color='gray' face='arial'>El tiempo de análisis es de 2 días hábiles.<br>
													</td>
												</tr>

												<tr><td></td></tr>
												<tr>
													<td colspan='2' style='align-content: center' face='arial' valign='middle'><font face='arial' color='gray'><small face='arial'>Atentamente.<br>El equipo de massiva</small></font></td>
												</tr>
											</table>
											</div>
										</body>
										</html>";
			                //enviamos el correo
			                $mail->send();
			                //redireccionamos a la pagina para enviar mensaje
			                
			        } catch (Exception $e) {
			             $hola = '1';
			        }
					header ('location:../index.php?secc=simuladores&guaSim=1');
				}	
			}else{
				header ('location:../index.php?secc=simuladores&guaSim=2');
			}
		break;

		case "reenviar":
	
			$hola = strip_tags($correEnvia);
			//envaismos el correo al cliente
			$mail = new PHPMailer(true);                              
	        try {
	                //Server settings
	                $mail->SMTPDebug = 0;
	                $mail->isSMTP();
	                $mail->Host = 'mail.massiva.mx'; 
	                $mail->SMTPAuth = true;
	                $mail->Username = 'atencionclientes@massiva.mx';
	                $mail->Password = 'AtenCli_19';
	                $mail->SMTPSecure = 'tls';
	                $mail->Port = 587;

	                //Recipients
	                $mail->setFrom('atencionclientes@massiva.mx', 'Atención a clientes');
	                $mail->addAddress($hola, 'Cliente');     // Add a recipient
	                $mail->addAddress('dsanchez@massiva.mx','Recuperación de claves');               // Name is optional
	                $mail->addAddress('ahernandez@massiva.mx','Recuperación de claves');               // Name is optional

	                //Content
	                $mail->CharSet = 'UTF-8';
	                $mail->isHTML(true);                                  // Set email format to HTML
	                $mail->Subject = 'Cotización de contabilidad atrasada massiva';
	                $mail->Body    = "
	                         <!DOCTYPE html>
								<html lang='es'>
								<head>
								<meta http-equiv='Content-Type' content='text/html; charset=utf-8'/> 
								</head>
								<body>
									<div style='text-align:center;'>
									<table style='width: 100%' style='margin: 0 auto;'>
										<tr>
											<td colspan='2' style='align-content: center' face='arial'><font face='arial'><h1 style='align-items: center;' face='arial'>Cotización Contabilidad Atrasada<br></h1></font></td>
										</tr>

										<tr valign='middle'>
											<td colspan='2' style='align-content: center' face='arial' valign='middle'>
												<font face='arial'><h4 style='align-items: center;' face='arial'>
												<h5>
													<b>Forma jurídica:</b> Persona Moral.<br>
													<b>Costo: </b>  {$montoEnvia} .<br><br>

													<b>Una vez obtengamos tu e-firma podremos analizar tu contabilidad con exactitud.
													<br> Esta cotización podría variar después del análisis por massiva.</b> 
													
												</h5>
												</font>
											</td>
										</tr>

										<tr><td><br></td></tr>

										<tr>
											<td colspan='2'>
												<font color='gray' face='arial'>El tiempo de análisis es de 1 a 2 días hábiles.<br>
												Se requiere el registro para realizar dicho análisis <a href='https://massiva.mx/'>clic aquí</a>

											</td>
										</tr>

										<tr><td></td></tr>
										<tr>
											<td colspan='2' style='align-content: center' face='arial' valign='middle'><font face='arial' color='gray'><small face='arial'>Atentamente.<br>El equipo de massiva</small></font></td>
										</tr>
									</table>
									</div>
								</body>
								</html>";
	                //enviamos el correo
	                $mail->send();
	                //redireccionamos a la pagina para enviar mensaje
	                
	        } catch (Exception $e) {
	             $hola = '1';
	        }
			$rsptaLog = $simula->accionReenvio($usuarioSe,$fechaAccion);
			header ('location:../index.php?secc=contaatrasas&guaSim=2');
			
				
		break;
			
		case "eliminar":
			$elimnmm = $simula->elimino($idContaAtrasada);
			if($elimnmm){
				$rsptaLog = $simula->accionElimina($usuarioSe,$fechaAccion);
				header ('location:../index.php?secc=contaatrasas&guaSim=3');

			}
		break;
		
			
 	}
?>