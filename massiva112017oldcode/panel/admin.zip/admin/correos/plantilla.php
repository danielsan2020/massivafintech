<!DOCTYPE html>
<html lang='es'>
<head>
 
</head>
<body>
    <div style='text-align:center;'>
    <table style='width: 100%' style='margin: 0 auto;'>
        <tr>
            <td colspan='2' style='align-content: center' face='arial'><font face='arial'><h1 style='align-items: center;' face='arial'>¡Bienvenida/o a massiva!</h1></font></td>
        </tr>
        <tr>
            <td colspan='2'>
                <font color='gray' face='arial'>
                Inicia sesión y conéctate con tu contabilidad al día.<br>
                Aquí hay información de ayuda para que puedas empezar:<br>
                </font>
            </td>
        </tr>
        <tr><td></td></tr>
        <tr>
            <td><b><font face='arial'>Número de usuario:</b></font><br></td>
            
        </tr>
        <tr>
            <td valign='middle'><b><font face='arial'>Nombre:</b></font><br></td>
            
        </tr>
        <tr>
            <td><b><font face='arial'>Usuario:</b></font><br></td>
            
        </tr>
        <tr>
            <td><b><font face='arial'>Contraseña:</b></font><br></td>
            
        </tr>
        <tr valign='middle'>
            <td colspan='2' style='align-content: center' face='arial' valign='middle'><font face='arial'><h4 style='align-items: center;' face='arial'>¡Estamos aquí para ayudarte!</h4></font></td>
        </tr>
        <tr>
            <td colspan='2' style='align-content: center' face='arial' valign='middle'><font face='arial' color='gray'><small face='arial'>Massiva protegerá siempre tu privacidad y confidencialidad de datos.<br> Si quieres saber más revisa por favor en Aviso de Privacidad y en Términos y Condiciones dentro de www.massiva.mx</small></font></td>
        </tr>
        
    </table>
    </div>
</body>
</html>