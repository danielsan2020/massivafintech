<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>:: MASSIVA | Plataforma contable innovadora ::</title>
	<!--estilos-->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="css/plugins/toastr/toastr.min.css" rel="stylesheet">
    <link href="js/plugins/gritter/jquery.gritter.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
	<link href="css/plugins/dataTables/datatables.min.css" rel="stylesheet">
	<link href="css/plugins/jsTree/style.min.css" rel="stylesheet">
	<link href="css/personalizado.css" rel="stylesheet">
	<link href="css/plugins/steps/jquery.steps.css" rel="stylesheet">
	<link href="css/plugins/ladda/ladda-themeless.min.css" rel="stylesheet">
    <link rel="shortcut icon" type="image/x-icon" href="../../images/massiva.ico" />
    <link href="css/plugins/ladda/ladda-themeless.min.css" rel="stylesheet">
	<!--script-->
	<script src="js/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
    
    <script src="js/plugins/flot/jquery.flot.js"></script>
    <script src="js/plugins/flot/jquery.flot.tooltip.min.js"></script>
    <script src="js/plugins/flot/jquery.flot.spline.js"></script>
    <script src="js/plugins/flot/jquery.flot.resize.js"></script>
    <script src="js/plugins/flot/jquery.flot.pie.js"></script>
    <script src="js/plugins/peity/jquery.peity.min.js"></script>
    
    <script src="js/inspinia.js"></script>
    <script src="js/plugins/pace/pace.min.js"></script>
    <script src="js/plugins/jquery-ui/jquery-ui.min.js"></script>
    <script src="js/plugins/gritter/jquery.gritter.min.js"></script>
    
    
    <script src="js/plugins/chartJs/Chart.min.js"></script>
    <script src="js/plugins/toastr/toastr.min.js"></script>
	<script src="js/plugins/dataTables/datatables.min.js"></script>
	<script src="js/plugins/jsTree/jstree.min.js"></script>
    <script src="js/plugins/steps/jquery.steps.min.js"></script>
    <script src="js/plugins/validate/jquery.validate.min.js"></script>
	<script src="js/general.js"></script>
	<script src="js/plugins/ladda/spin.min.js"></script>
    <script src="js/plugins/ladda/ladda.min.js"></script>
    <script src="js/plugins/ladda/ladda.jquery.min.js"></script>
	<script src="js/plugins/jasny/jasny-bootstrap.min.js"></script>
    
	<script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

	<!--datos para el wys--->
	<link rel="stylesheet" href="plugins/minified/themes/default.min.css" id="theme-style" />
	<script src="plugins/minified/sceditor.min.js"></script>
	<script src="plugins/minified/icons/monocons.js"></script>
	<script src="plugins/minified/formats/xhtml.min.js"></script>
    <script src="js/plugins/bootstrapTour/bootstrap-tour.min.js"></script>


    <!-- Bootstrap Tour -->
    <link href="css/plugins/bootstrapTour/bootstrap-tour.min.css" rel="stylesheet">
    <script src="js/plugins/bootstrapTour/bootstrap-tour.min.js"></script>
   
   <!--para las lista desplegables--->
   <script src="js/plugins/pace/pace.min.js"></script>

   <!-- Ladda -->
   <script src="js/plugins/ladda/spin.min.js"></script>
    <script src="js/plugins/ladda/ladda.min.js"></script>
    <script src="js/plugins/ladda/ladda.jquery.min.js"></script>

    