//funcion para los numeros
function NumCheck(e, field) {
  key = e.keyCode ? e.keyCode : e.which
  // backspace
  if (key == 8) return true
  // 0-9
  if (key > 47 && key < 58) {
    if (field.value == "") return true
    regexp = /.[0-9]{5}$/
    return !(regexp.test(field.value))
  }
  // .
  if (key == 46) {
    if (field.value == "") return false
    regexp = /^[0-9]+$/
    return regexp.test(field.value)
  }
  // other key
  return false
 
}
//funcion para letras
function soloLetras(e){
       key = e.keyCode || e.which;
       tecla = String.fromCharCode(key).toLowerCase();
       letras = " áéíóúabcdefghijklmnñopqrstuvwxyz";
       especiales = "8-37-39-46";

       tecla_especial = false
       for(var i in especiales){
            if(key == especiales[i]){
                tecla_especial = true;
                break;
            }
        }

        if(letras.indexOf(tecla)==-1 && !tecla_especial){
            return false;
        }
    }

$(document).ready(function(){
	///funcion para la tabla
	$('.dataTables-example').DataTable({
	columns: [
			{ "width": "20%", "targets": 0 }
	],
	pageLength: 25,
	responsive: true,
	dom: '<"html5buttons"B>lTfgitp',
	buttons: [
	
		{extend: 'pdf', title: 'ExampleFile'},

		{extend: 'print',
			customize: function (win){
				$(win.document.body).addClass('white-bg');
				$(win.document.body).css('font-size', '10px');

				$(win.document.body).find('table')
						.addClass('compact')
						.css('font-size', 'inherit');
		}
		}
	],
	language: {
		processing:     "Procesando...",
		search:         "Buscar:",
		lengthMenu:     "Mostrar: _MENU_ elementos",
		info:           "Mostrando _START_ a _END_ de _TOTAL_ resultados",
		infoEmpty:      "Elemento 0 de 0 elementos encontrados",
		infoFiltered:   "(elementos filtrado _MAX_ de elementos maximos )",
		infoPostFix:    "",
		loadingRecords: "Cambios en Curso...",
		zeroRecords:    "No se encuentran elementos.",
		emptyTable:     "Tabla no disponible",
		paginate: {
			first:      "Adelante",
			previous:   "Anterior",
			next:       "Siguiente",
			last:       "Atrás"
		}

	}
	});
	
/**********************************************************************************************/
/****************************************Botones para cerrar los modals*************************************/
	//para el modal de nuevo
	$("#btncerranuevo").click(function(){	
		$('#nuevoPro').trigger("reset");
		$('#nuevoprodu').modal('hide');
		window.setTimeout('location.reload()');
	});
	
	///para editar
	$("#btnCierraEdita").click(function(){	
		$('#editar').modal('hide');
		window.setTimeout('location.reload()');
	});
	
	//boton para eliminar
	$("#btnEliminaDir").click(function(){	
		$('#ModalEliminar').modal('hide');
		window.setTimeout('location.reload()');
	});
	
	//boton para agregar entradad
	$("#btnCierEntrad").click(function(){	
		$('#agregarentrada').modal('hide');
		window.setTimeout('location.reload()');
	});
	
	//boton para salida
	$("#btnCierSalia").click(function(){	
		$('#agregaSalida').modal('hide');
		window.setTimeout('location.reload()');
	});
	
	
	

	/**********************************************************************************************/
	/****************************************editar*************************************/
	$('#editar').on('show.bs.modal', function (event) {
		var button = $(event.relatedTarget); // Button that triggered the modal
		var recipient = button.data('unoo');
		var recipientttt = button.data('doss');
		
		$.ajax({
			data:{idConProd:recipient},
			url:'controlador/inventarioActivoControlador.php',
            type:'POST',
			
            success:function(data){
				alert('entra');
				$('#holaaa').val('holaaa');
						
               
           }
        });

        //se abre el modal
        var modal = $(this);
        modal.find('.modal-body #idInventarioEdi').val(recipient);
        modal.find('.modal-body #logoTrae').val(recipientttt);
    });
	
	/**********************************************************************************************/
	/****************************************eliminar*************************************/
	$('#ModalEliminar').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget); // Button that triggered the modal
		var uno = button.data('doos');
		var dos = button.data('dooss');
		
        var modal = $(this);
		

        modal.find('.modal-body #idInventario2').val(uno);
		modal.find('.modal-body #imgref2').val(dos);
  	});
	
	///eliminar
	$("#btnElimin").click(function(){
		/*obtengo valores*/
		var accion = 'eliminar';
		var idInventario2 = $('#idInventario2').val();
		var imgref2 = $('#imgref2').val();
		/*metodo ajax*/
		$.ajax({
            data: {accion,idInventario2,imgref2},
            url: "controlador/inventarioActivoControlador2.php",
            type: 'POST',
            success: function (response){
                $("#alertAccion").append('<div class="alert alert-success text-center">Se elimino el producto</div>');
				$('#ModalEliminar').modal('hide');
				window.setTimeout('location.reload()', 3000);
            },
            error: function(response,status,error){
                $("#alertAccion").append('<div class="alert alert-danger text-center">Ocurrio un error favor de verificar sus datos .</div>');
				$('#ModalEliminar').modal('hide');
				window.setTimeout('location.reload()', 3000);
            }
        })
		
		
	});
	
	/**********************************************************************************************/
	/****************************************agregar entrada de producto*************************************/
	$('#agregarentrada').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget); // Button that triggered the modal
		var unoo = button.data('unoo');
		var doso = button.data('doso');

        var modal = $(this);
		
        modal.find('.modal-body #idInventarioE').val(unoo);
		modal.find('.modal-body #CasntE').val(doso);
  	});
	
	//agregar la entrada
	$("#agreEntrada").click(function(){
		/*obtengo valores*/
		var accion = 'agreEntrada';
		var idInventarioE = $('#idInventarioE').val();
		var fechaEntradaE = $('#fechaEntradaE').val();
		var cantidadE = $('#cantidadE').val();
		var precioE = $('#precioE').val();
		var proveedorE = $('#proveedorE').val();
		var unidadE = $('#unidadE').val();
		var CasntE = $('#CasntE').val();
		
		/*metodo ajax*/
		$.ajax({
            data: {accion,idInventarioE,fechaEntradaE,cantidadE,precioE,proveedorE,unidadE,CasntE},
            url: "controlador/inventarioActivoControlador2.php",
            type: 'POST',
            success: function (response){
                $("#alertAccion").append('<div class="alert alert-success text-center">Se agregó tu entrada al producto</div>');
				$('#agregarentrada').modal('hide');
				window.setTimeout('location.reload()', 3000);
            },
            error: function(response,status,error){
                $("#alertAccion").append('<div class="alert alert-danger text-center">Ocurrió un error, por favor verificar tus datos .</div>');
				$('#agregarentrada').modal('hide');
				window.setTimeout('location.reload()', 3000);
            }
        })
		
		
	});
	
	/**********************************************************************************************/
	/****************************************agregar entrada de producto*************************************/
	$('#agregaSalida').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget); // Button that triggered the modal
		var unoo = button.data('unoo');
		var doso = button.data('doso');

        var modal = $(this);
		
        modal.find('.modal-body #idInventarioE1').val(unoo);
		modal.find('.modal-body #CasntE1').val(doso);
  	});
	
	//agregar salida
	$("#agreSalidaddf").click(function(){
		/*obtengo valores*/
		var accion = 'agreSalida';
		var idInventarioE1 = $('#idInventarioE1').val();
		var fechaEntradaE1 = $('#fechaEntradaE1').val();
		var cantidadE1 = $('#cantidadE1').val();
		var precioE1 = $('#precioE1').val();
		var proveedorE1 = $('#proveedorE1').val();
		var unidadE1 = $('#unidadE1').val();
		var CasntE1 = $('#CasntE1').val();
		
		/*metodo ajax*/
		$.ajax({
            data: {accion,idInventarioE1,fechaEntradaE1,cantidadE1,precioE1,proveedorE1,unidadE1,CasntE1},
            url: "controlador/inventarioActivoControlador2.php",
            type: 'POST',
            success: function (response){
                $("#alertAccion").append('<div class="alert alert-success text-center">Se agregó tu salida al producto</div>');
				$('#agregaSalida').modal('hide');
				window.setTimeout('location.reload()', 3000);
            },
            error: function(response,status,error){
                $("#alertAccion").append('<div class="alert alert-danger text-center">Ocurrió un error, por favor verificar tus datos .</div>');
				$('#agregaSalida').modal('hide');
				window.setTimeout('location.reload()', 3000);
            }
        })
		
		
	});

	/**********************************************************************************************/
	/****************************************eliminar servicio*************************************/
	$('#eliminaServicios').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget); // Button that triggered the modal
		var uno = button.data('doos');
        var modal = $(this);
        modal.find('.modal-body #idServicio').val(uno);
		
  	});

	
});