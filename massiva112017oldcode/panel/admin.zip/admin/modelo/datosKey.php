<?php 
	define('METHOD','AES-256-CBC');
	define('SECRET_KEY','Ma551Va#');
	define('SECRET_KEY2','Ma552Va#');
	define('SECRET_KEY3','Ma553Va#');
	define('SECRET_KEY4','Ma554Va#');
	define('SECRET_IV','110487');
	define('servicekeyAfter','3db8vgd5feguis54');