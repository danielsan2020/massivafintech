<?php

/****************************************************************/
// DATOS DE CONEXION GENERALES PARA EL PROYECTO                 //
// CREACION DEL ARCHIVO: 21/08/2018                             //
// AUTOR: Hevasoft.com                                          //
/****************************************************************/

/*
//local
//Ip de la pc servidor de base de datos
define("DB_HOST","localhost");
//Nombre de la base de datos
define("DB_NAME", "massiva");
//Usuario de la base de datos
define("DB_USERNAME", "root");
//Contraseña del usuario de la base de datos
define("DB_PASSWORD", "");
//definimos la codificación de los caracteres
define("DB_ENCODE","utf8");
//Definimos una constante como nombre del proyecto
define("PRO_NOMBRE","Massiva");*/


//produccion 
//Ip de la pc servidor de base de datos
define("DB_HOST","localhost");
//Nombre de la base de datos
define("DB_NAME", "sinad18_massiva");
//Usuario de la base de datos
define("DB_USERNAME", "sinad18_massiva");
//Contraseña del usuario de la base de datos
define("DB_PASSWORD", "B}[&iCPR8#B[");
//definimos la codificación de los caracteres
define("DB_ENCODE","utf8");
//Definimos una constante como nombre del proyecto


?>