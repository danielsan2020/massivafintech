<?php
/****************************************************************/
// MODELO PARA LAS FUNCIONES GENERALES                          //
// CREACION DEL ARCHIVO: 15/10/2018                             //
// MODIFICA Y/O TRABAJA: Azael HV                               //
// PROYECTO: Ruta                                               //
/****************************************************************/

require_once "Conexion.php";

Class simula{
	
	//Implementamos nuestro constructor
	public function __construct(){}
	
	/***********************Seccion para guardar los logs*****************************/
    //nuevo seguro
    public function accionAgregoContapf($usuarioSe,$fechaAccion){
		$sql = "INSERT INTO tbl_log_acciones (id_usuario,idLogs,fechaCreacion)VALUES('$usuarioSe','63','$fechaAccion')";
		return ejecutarConsulta($sql);
	}

	public function accionAgregoContapm($usuarioSe,$fechaAccion){
		$sql = "INSERT INTO tbl_log_acciones (id_usuario,idLogs,fechaCreacion)VALUES('$usuarioSe','64','$fechaAccion')";
		return ejecutarConsulta($sql);
	}

	public function accionReenvio($usuarioSe,$fechaAccion){
		$sql = "INSERT INTO tbl_log_acciones (id_usuario,idLogs,fechaCreacion)VALUES('$usuarioSe','65','$fechaAccion')";
		return ejecutarConsulta($sql);
	}

	public function accionElimina($usuarioSe,$fechaAccion){
		$sql = "INSERT INTO tbl_log_acciones (id_usuario,idLogs,fechaCreacion)VALUES('$usuarioSe','66','$fechaAccion')";
		return ejecutarConsulta($sql);
	}

	
	
    /********************************************************************************/
	
    //informacion para la datatable
    public function informacionTabla(){
        $sql="SELECT * FROM tbl_inventario_seguros ORDER BY idSeguros DESC";
		return ejecutarConsulta($sql); 
    }

	//agregamos nuevo seguro
	public function agregacontaatrapf($montoCal,$rfc,$nombre,$ape_paterno,$ape_materno,$correo,$periodoRegu,$obliga,$cheInteres,$cheasalariado,$chearrendamiento,$cheservicios,$cheempresaria,$cherif,$estatus,$creado,$fechaAccion,$usuarioSe){
		$sql = "INSERT INTO tbl_contabilidadatrasada_pf (rfc,nombre,ape_paterno,ape_materno,correo,periodo,obligaciones,cheInteres,cheasalariado,chearrendamiento,cheservicios,cheempresaria,cherif,estatus,creado,usuarioCreacion,fechaCreacion,monto)
		VALUES('$rfc','$nombre','$ape_paterno','$ape_materno','$correo','$periodoRegu','$obliga','$cheInteres','$cheasalariado','$chearrendamiento','$cheservicios','$cheempresaria','$cherif','$estatus','$creado','$usuarioSe','$fechaAccion','$montoCal')";
		return ejecutarConsulta($sql);
	}
	public function agregacontaatrapf2($montoCal,$rfc,$nombre,$ape_paterno,$ape_materno,$correo,$periodoRegu,$obliga,$cheInteres,$cheasalariado,$chearrendamiento,$cheservicios,$cheempresaria,$cherif,$estatus,$creado,$fechaAccion,$usuarioSe,$mesesin){
		$sql = "INSERT INTO tbl_contabilidadatrasada_pf (rfc,nombre,ape_paterno,ape_materno,correo,periodo,obligaciones,cheInteres,cheasalariado,chearrendamiento,cheservicios,cheempresaria,cherif,estatus,creado,usuarioCreacion,fechaCreacion,monto,mesesin)
		VALUES('$rfc','$nombre','$ape_paterno','$ape_materno','$correo','$periodoRegu','$obliga','$cheInteres','$cheasalariado','$chearrendamiento','$cheservicios','$cheempresaria','$cherif','$estatus','$creado','$usuarioSe','$fechaAccion','$montoCal','$mesesin')";
		return ejecutarConsulta($sql);
	}

	//agregamos nuevo seguro
	public function agregacontaatrapm($montoCal1,$rfc1,$nombre1,$ape_paterno1,$ape_materno1,$correo1,$periodoRegu2,$obliga2,$movIngUno2,$regeneral,$fineslucra,$estatus1,$creado1,$fechaAccion,$usuarioSe){
		$sql = "INSERT INTO tbl_contabilidadatrasada_pm (rfc,nombre,ape_paterno,ape_materno,correo,periodo,obligaciones,ingresos,regeneral,fineslucra,estatus,creado,usuarioCreacion,fechaCreacion,monto)
		VALUES('$rfc1','$nombre1','$ape_paterno1','$ape_materno1','$correo1','$periodoRegu2','$obliga2','$movIngUno2','$regeneral','$fineslucra','$estatus1','$creado1','$usuarioSe','$fechaAccion','$montoCal1')";
		return ejecutarConsulta($sql);
	}

	//eliminamos el presupuesto
	public function elimino($idContaAtrasada){
		$sql = "DELETE FROM tbl_contabilidadatrasada_pf WHERE idContaAtrasada='$idContaAtrasada'";
		return ejecutarConsulta($sql);
	}

	
}